# Script to ingest firewall and SIEM logs into Flink
