# Sample Flink pipeline for anomaly detection
